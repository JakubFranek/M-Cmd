/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "//gigadisk2.ro.vutbr.cz/GIGADISK2/home/7/2/0/186027/bndi/VGA/VGA1/h_count.vhd";
extern char *IEEE_P_2592010699;
extern char *IEEE_P_1242562249;

char *ieee_p_1242562249_sub_1547198987_1035706684(char *, char *, char *, char *, char *, char *);
char *ieee_p_1242562249_sub_180853171_1035706684(char *, char *, int , int );
char *ieee_p_1242562249_sub_1919365254_1035706684(char *, char *, char *, char *, int );
char *ieee_p_1242562249_sub_1919437128_1035706684(char *, char *, char *, char *, int );
unsigned char ieee_p_1242562249_sub_2110375371_1035706684(char *, char *, char *, char *, char *);
unsigned char ieee_p_2592010699_sub_1744673427_503743352(char *, char *, unsigned int , unsigned int );


static void work_a_3052423368_3212880686_p_0(char *t0)
{
    char *t1;
    unsigned char t2;
    char *t3;
    char *t4;
    unsigned char t5;
    unsigned char t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;

LAB0:    xsi_set_current_line(22, ng0);
    t1 = (t0 + 1312U);
    t2 = ieee_p_2592010699_sub_1744673427_503743352(IEEE_P_2592010699, t1, 0U, 0U);
    if (t2 != 0)
        goto LAB2;

LAB4:
LAB3:    t1 = (t0 + 4536);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(23, ng0);
    t3 = (t0 + 1032U);
    t4 = *((char **)t3);
    t5 = *((unsigned char *)t4);
    t6 = (t5 == (unsigned char)3);
    if (t6 != 0)
        goto LAB5;

LAB7:
LAB6:    goto LAB3;

LAB5:    xsi_set_current_line(24, ng0);
    t3 = (t0 + 1832U);
    t7 = *((char **)t3);
    t3 = (t0 + 4664);
    t8 = (t3 + 56U);
    t9 = *((char **)t8);
    t10 = (t9 + 56U);
    t11 = *((char **)t10);
    memcpy(t11, t7, 10U);
    xsi_driver_first_trans_fast(t3);
    goto LAB6;

}

static void work_a_3052423368_3212880686_p_1(char *t0)
{
    char t3[16];
    char t4[16];
    char t5[16];
    char t6[16];
    char t7[16];
    char t9[16];
    char t12[16];
    char t15[16];
    char t27[16];
    char *t1;
    char *t2;
    char *t8;
    char *t10;
    char *t11;
    char *t13;
    char *t14;
    char *t16;
    char *t17;
    char *t18;
    unsigned char t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t28;
    char *t29;
    char *t30;
    char *t31;
    unsigned int t32;
    unsigned int t33;
    unsigned char t34;
    char *t35;
    char *t36;
    char *t37;
    char *t38;
    char *t39;
    char *t40;

LAB0:    xsi_set_current_line(29, ng0);
    t1 = (t0 + 1672U);
    t2 = *((char **)t1);
    t1 = (t0 + 7480U);
    t8 = ieee_p_1242562249_sub_180853171_1035706684(IEEE_P_1242562249, t7, 16, 10);
    t10 = ieee_p_1242562249_sub_180853171_1035706684(IEEE_P_1242562249, t9, 640, 10);
    t11 = ieee_p_1242562249_sub_1547198987_1035706684(IEEE_P_1242562249, t6, t8, t7, t10, t9);
    t13 = ieee_p_1242562249_sub_180853171_1035706684(IEEE_P_1242562249, t12, 96, 10);
    t14 = ieee_p_1242562249_sub_1547198987_1035706684(IEEE_P_1242562249, t5, t11, t6, t13, t12);
    t16 = ieee_p_1242562249_sub_180853171_1035706684(IEEE_P_1242562249, t15, 48, 10);
    t17 = ieee_p_1242562249_sub_1547198987_1035706684(IEEE_P_1242562249, t4, t14, t5, t16, t15);
    t18 = ieee_p_1242562249_sub_1919437128_1035706684(IEEE_P_1242562249, t3, t17, t4, 1);
    t19 = ieee_p_1242562249_sub_2110375371_1035706684(IEEE_P_1242562249, t2, t1, t18, t3);
    if (t19 != 0)
        goto LAB3;

LAB4:
LAB5:    t28 = (t0 + 1672U);
    t29 = *((char **)t28);
    t28 = (t0 + 7480U);
    t30 = ieee_p_1242562249_sub_1919365254_1035706684(IEEE_P_1242562249, t27, t29, t28, 1);
    t31 = (t27 + 12U);
    t32 = *((unsigned int *)t31);
    t33 = (1U * t32);
    t34 = (10U != t33);
    if (t34 == 1)
        goto LAB7;

LAB8:    t35 = (t0 + 4728);
    t36 = (t35 + 56U);
    t37 = *((char **)t36);
    t38 = (t37 + 56U);
    t39 = *((char **)t38);
    memcpy(t39, t30, 10U);
    xsi_driver_first_trans_fast(t35);

LAB2:    t40 = (t0 + 4552);
    *((int *)t40) = 1;

LAB1:    return;
LAB3:    t20 = xsi_get_transient_memory(10U);
    memset(t20, 0, 10U);
    t21 = t20;
    memset(t21, (unsigned char)2, 10U);
    t22 = (t0 + 4728);
    t23 = (t22 + 56U);
    t24 = *((char **)t23);
    t25 = (t24 + 56U);
    t26 = *((char **)t25);
    memcpy(t26, t20, 10U);
    xsi_driver_first_trans_fast(t22);
    goto LAB2;

LAB6:    goto LAB2;

LAB7:    xsi_size_not_matching(10U, t33, 0);
    goto LAB8;

}

static void work_a_3052423368_3212880686_p_2(char *t0)
{
    char t4[16];
    char t5[16];
    char t6[16];
    char t7[16];
    char t8[16];
    char t10[16];
    char t13[16];
    char t16[16];
    unsigned char t1;
    char *t2;
    char *t3;
    char *t9;
    char *t11;
    char *t12;
    char *t14;
    char *t15;
    char *t17;
    char *t18;
    char *t19;
    unsigned char t20;
    char *t21;
    char *t22;
    unsigned char t23;
    unsigned char t24;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    char *t29;
    char *t30;
    char *t31;
    char *t32;
    char *t33;
    char *t34;

LAB0:    xsi_set_current_line(32, ng0);
    t2 = (t0 + 1672U);
    t3 = *((char **)t2);
    t2 = (t0 + 7480U);
    t9 = ieee_p_1242562249_sub_180853171_1035706684(IEEE_P_1242562249, t8, 16, 10);
    t11 = ieee_p_1242562249_sub_180853171_1035706684(IEEE_P_1242562249, t10, 640, 10);
    t12 = ieee_p_1242562249_sub_1547198987_1035706684(IEEE_P_1242562249, t7, t9, t8, t11, t10);
    t14 = ieee_p_1242562249_sub_180853171_1035706684(IEEE_P_1242562249, t13, 96, 10);
    t15 = ieee_p_1242562249_sub_1547198987_1035706684(IEEE_P_1242562249, t6, t12, t7, t14, t13);
    t17 = ieee_p_1242562249_sub_180853171_1035706684(IEEE_P_1242562249, t16, 48, 10);
    t18 = ieee_p_1242562249_sub_1547198987_1035706684(IEEE_P_1242562249, t5, t15, t6, t17, t16);
    t19 = ieee_p_1242562249_sub_1919437128_1035706684(IEEE_P_1242562249, t4, t18, t5, 1);
    t20 = ieee_p_1242562249_sub_2110375371_1035706684(IEEE_P_1242562249, t3, t2, t19, t4);
    if (t20 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB3;

LAB4:
LAB8:    t29 = (t0 + 4792);
    t30 = (t29 + 56U);
    t31 = *((char **)t30);
    t32 = (t31 + 56U);
    t33 = *((char **)t32);
    *((unsigned char *)t33) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t29);

LAB2:    t34 = (t0 + 4568);
    *((int *)t34) = 1;

LAB1:    return;
LAB3:    t21 = (t0 + 4792);
    t25 = (t21 + 56U);
    t26 = *((char **)t25);
    t27 = (t26 + 56U);
    t28 = *((char **)t27);
    *((unsigned char *)t28) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t21);
    goto LAB2;

LAB5:    t21 = (t0 + 1032U);
    t22 = *((char **)t21);
    t23 = *((unsigned char *)t22);
    t24 = (t23 == (unsigned char)3);
    t1 = t24;
    goto LAB7;

LAB9:    goto LAB2;

}

static void work_a_3052423368_3212880686_p_3(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;

LAB0:    xsi_set_current_line(34, ng0);

LAB3:    t1 = (t0 + 1672U);
    t2 = *((char **)t1);
    t1 = (t0 + 4856);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memcpy(t6, t2, 10U);
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t7 = (t0 + 4584);
    *((int *)t7) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}


extern void work_a_3052423368_3212880686_init()
{
	static char *pe[] = {(void *)work_a_3052423368_3212880686_p_0,(void *)work_a_3052423368_3212880686_p_1,(void *)work_a_3052423368_3212880686_p_2,(void *)work_a_3052423368_3212880686_p_3};
	xsi_register_didat("work_a_3052423368_3212880686", "isim/tb_vga_sync2_isim_beh.exe.sim/work/a_3052423368_3212880686.didat");
	xsi_register_executes(pe);
}
